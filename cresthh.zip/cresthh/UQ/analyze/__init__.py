__all__ = ["sobol_analyze", "morris", "extended_fast",\
 "moments", "correlations", "hypothesis",\
 "confidence",\
 "dgsm", "delta", "sobol_svm"]