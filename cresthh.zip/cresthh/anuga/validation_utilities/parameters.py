#! /usr/bin/python

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="stephen"
__date__ ="$20/08/2012 11:20:00 PM$"

alg = 'DE1'
cfl = 1.0

# If a file local_parameters.py exits in current directory
# use the parameters defined there to override the parameters set here.
try:
    from local_parameters import *
except:
    pass







