"""Stored revision info.

This file provides the version for distributions that are not accessing Subversion directly.
The file is automatically generated and should not be modified manually.
"""

revision_info = """
"""