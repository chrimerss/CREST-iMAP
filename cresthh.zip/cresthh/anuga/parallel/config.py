#! /usr/bin/python

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="stephen"
__date__ ="$27/08/2012 8:58:23 PM$"


ghost_layer_width = 2


if __name__ == "__main__":
    print "Hello World";
