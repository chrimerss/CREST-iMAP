"""compile.py - compile Python C-extension

   Commandline usage: 
     python compile.py <filename>

"""

import os
execfile('..' + os.sep + 'utilities' + os.sep + 'compile.py')
