"""
    Validation tests
"""

from numpy.testing import Tester
test = Tester().test


from typeset_report import typeset_report
from run_validation import run_validation_script
from produce_report import produce_report
from save_parameters_tex import save_parameters_tex



