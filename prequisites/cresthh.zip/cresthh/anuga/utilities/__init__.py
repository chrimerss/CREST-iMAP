"""
    Generic utility classes not concerned with the specifics of ANUGA.
    
    Utility functions for managing files, numerical constants, and generic
    mathematical and programming idioms.
"""

from numpy.testing import Tester
test = Tester().test


