General utilities for the AnuGa inundation modelling project

