"""Make directory available as a Python package
"""

from cresthh.anuga.geospatial_data.geospatial_data import *


from numpy.testing import Tester
test = Tester().test

