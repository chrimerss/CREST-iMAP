The module here (maxasc.py) contains a function that takes one or more
ASC filenames in a list and produces an output ASC file that is the 
element-wise max() of each of the input ASC files.

Of course, the input files must all have the same shape.