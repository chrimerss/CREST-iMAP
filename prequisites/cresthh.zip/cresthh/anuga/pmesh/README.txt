
	
To run pmesh;
	python graphical_mesh_generator.py 
	
INSTRUCTIONS FOR USING PMESH

Pmesh will let the user select various modes. The current
allowable modes are vertex or segment.  The mode describes what sort
of object is added or selected in response to mouse clicks.  When
changing modes any prior selected objects become deselected.

In general the left mouse button will add an object and the right
mouse button will select an object.  A selected object can deleted
by pressing the the middle mouse button (scroll bar).



