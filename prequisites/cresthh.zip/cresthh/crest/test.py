from crest_core import model

args= (50, 5, 0.2,0.5,0.6,0.2,0.4,0.6,0.45,0.5,0.6,0.4,0.8,0.4,
0.6,0.4,0.2,0.1,0.8,1)

print model(*args)