class Crest {
 public:
	float model();
}

